"""Version info."""

__version_info__ = (0, 9, 62)
__version__ = '.'.join(str(v) for v in __version_info__)
